package ma.projet.tax_tnb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaxTnbApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaxTnbApplication.class, args);
    }

}
